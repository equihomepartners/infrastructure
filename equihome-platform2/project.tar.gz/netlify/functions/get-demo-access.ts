import { Handler } from '@netlify/functions';
import { MongoClient } from 'mongodb';

const MONGODB_URI = process.env.MONGODB_URI;
const DB_NAME = 'equihome-demo';
const API_KEY = process.env.ADMIN_API_KEY;

const handler: Handler = async (event) => {
  // Verify API key
  const providedKey = event.headers['x-api-key'];
  if (providedKey !== API_KEY) {
    return {
      statusCode: 401,
      body: JSON.stringify({ error: 'Unauthorized' })
    };
  }

  try {
    const client = new MongoClient(MONGODB_URI as string);
    await client.connect();

    const collection = client.db(DB_NAME).collection('demo-access');
    
    // Get all demo access records, sorted by timestamp
    const records = await collection
      .find({})
      .sort({ timestamp: -1 })
      .toArray();

    await client.close();

    return {
      statusCode: 200,
      body: JSON.stringify(records)
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Failed to retrieve records' })
    };
  }
};

export { handler };