import { Handler } from '@netlify/functions';
import { MongoClient } from 'mongodb';

const MONGODB_URI = process.env.MONGODB_URI;
const DB_NAME = 'equihome-demo';

const handler: Handler = async (event) => {
  // Only allow POST requests
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      body: 'Method Not Allowed'
    };
  }

  try {
    const client = new MongoClient(MONGODB_URI as string);
    await client.connect();

    const data = JSON.parse(event.body || '{}');
    const collection = client.db(DB_NAME).collection('demo-access');

    await collection.insertOne({
      ...data,
      timestamp: new Date(),
      ip: event.headers['x-forwarded-for'] || 'unknown'
    });

    await client.close();

    return {
      statusCode: 200,
      body: JSON.stringify({ message: 'Access logged successfully' })
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Failed to log access' })
    };
  }
};

export { handler };