import React, { useState } from 'react';
import { Brain, Database, Shield, Network, GitBranch, Workflow, Server, Lock } from 'lucide-react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  PointElement
} from 'chart.js';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '../ui/tabs';
import DataProcessingView from './tech/DataProcessingView';
import AIArchitectureView from './tech/AIArchitectureView';
import MLPipelineView from './tech/MLPipelineView';
import InfrastructureView from './tech/InfrastructureView';
import SecurityView from './tech/SecurityView';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  PointElement
);

const TechnicalInfrastructure: React.FC = () => {
  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Technical Infrastructure</h2>
          <p className="text-gray-600 mt-1">Comprehensive overview of Equihome's AI/ML architecture</p>
        </div>
        <div className="flex items-center space-x-3">
          <span className="px-3 py-1 text-xs font-medium bg-green-100 text-green-800 rounded-full">
            Production v2.1
          </span>
          <span className="px-3 py-1 text-xs font-medium bg-blue-100 text-blue-800 rounded-full">
            99.99% Uptime
          </span>
        </div>
      </div>

      <Tabs defaultValue="dataProcessing" className="w-full">
        <TabsList>
          <TabsTrigger value="dataProcessing">
            <Database className="h-5 w-5 mr-2" />
            Data Processing
          </TabsTrigger>
          <TabsTrigger value="aiArchitecture">
            <Brain className="h-5 w-5 mr-2" />
            AI Architecture
          </TabsTrigger>
          <TabsTrigger value="mlPipeline">
            <Server className="h-5 w-5 mr-2" />
            ML Pipeline
          </TabsTrigger>
          <TabsTrigger value="infrastructure">
            <Server className="h-5 w-5 mr-2" />
            Infrastructure
          </TabsTrigger>
          <TabsTrigger value="security">
            <Shield className="h-5 w-5 mr-2" />
            Security
          </TabsTrigger>
        </TabsList>

        <TabsContent value="dataProcessing">
          <DataProcessingView />
        </TabsContent>
        <TabsContent value="aiArchitecture">
          <AIArchitectureView />
        </TabsContent>
        <TabsContent value="mlPipeline">
          <MLPipelineView />
        </TabsContent>
        <TabsContent value="infrastructure">
          <InfrastructureView />
        </TabsContent>
        <TabsContent value="security">
          <SecurityView />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default TechnicalInfrastructure;