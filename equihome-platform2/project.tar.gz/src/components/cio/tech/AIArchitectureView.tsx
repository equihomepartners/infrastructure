import React from 'react';
import { Brain, Zap, GitBranch, LineChart, Database } from 'lucide-react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  PointElement
} from 'chart.js';
import { Bar, Line } from 'react-chartjs-2';

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  PointElement
);

const AIArchitectureView: React.FC = () => {
  // Model performance metrics
  const modelPerformanceData = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
    datasets: [
      {
        label: 'Prediction Accuracy',
        data: [95.2, 96.1, 96.8, 97.2, 97.8, 98.1],
        borderColor: '#3b82f6',
        tension: 0.4
      },
      {
        label: 'Risk Assessment Precision',
        data: [94.8, 95.5, 96.2, 96.8, 97.1, 97.5],
        borderColor: '#10b981',
        tension: 0.4
      }
    ]
  };

  return (
    <div className="space-y-8">
      {/* AI System Overview */}
      <div className="bg-white rounded-lg shadow-sm p-6">
        <h3 className="text-xl font-semibold text-gray-900 mb-6">AI System Architecture</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-blue-50 rounded-lg p-4">
            <h4 className="flex items-center text-blue-900 font-medium mb-2">
              <Brain className="h-5 w-5 mr-2" />
              Neural Networks
            </h4>
            <ul className="space-y-2 text-blue-800 text-sm">
              <li>• Deep learning models</li>
              <li>• Pattern recognition</li>
              <li>• Risk assessment</li>
            </ul>
          </div>
          
          <div className="bg-green-50 rounded-lg p-4">
            <h4 className="flex items-center text-green-900 font-medium mb-2">
              <GitBranch className="h-5 w-5 mr-2" />
              Decision Trees
            </h4>
            <ul className="space-y-2 text-green-800 text-sm">
              <li>• Rule-based logic</li>
              <li>• Risk classification</li>
              <li>• Deal structuring</li>
            </ul>
          </div>
          
          <div className="bg-purple-50 rounded-lg p-4">
            <h4 className="flex items-center text-purple-900 font-medium mb-2">
              <LineChart className="h-5 w-5 mr-2" />
              Predictive Models
            </h4>
            <ul className="space-y-2 text-purple-800 text-sm">
              <li>• Return forecasting</li>
              <li>• Market prediction</li>
              <li>• Trend analysis</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Model Performance Chart */}
      <div className="bg-white rounded-lg shadow-sm p-6">
        <h3 className="text-xl font-semibold text-gray-900 mb-6">Model Performance Metrics</h3>
        <div className="h-80">
          <Line
            data={modelPerformanceData}
            options={{
              responsive: true,
              maintainAspectRatio: false,
              scales: {
                y: {
                  beginAtZero: false,
                  min: 90,
                  max: 100
                }
              }
            }}
          />
        </div>
      </div>
    </div>
  );
};

export default AIArchitectureView;