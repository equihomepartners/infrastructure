import React from 'react';
import { GitBranch, Brain, LineChart, RefreshCcw, Database } from 'lucide-react';
import { Line } from 'react-chartjs-2';

const MLPipelineView: React.FC = () => {
  // Model accuracy metrics over time
  const modelAccuracyData = {
    labels: ['Q1 2023', 'Q2 2023', 'Q3 2023', 'Q4 2023', 'Q1 2024', 'Q2 2024'],
    datasets: [
      {
        label: 'Valuation Accuracy',
        data: [94.2, 95.1, 95.8, 96.4, 97.1, 97.8],
        borderColor: '#3b82f6',
        tension: 0.4
      },
      {
        label: 'Risk Assessment',
        data: [93.8, 94.5, 95.2, 95.8, 96.4, 97.2],
        borderColor: '#10b981',
        tension: 0.4
      }
    ]
  };

  return (
    <div className="space-y-8">
      {/* ML Pipeline Overview */}
      <div className="bg-white rounded-lg shadow-sm p-6">
        <h3 className="text-xl font-semibold text-gray-900 mb-6">Machine Learning Pipeline</h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {[
            {
              title: 'Data Ingestion',
              icon: Database,
              color: 'blue',
              metrics: ['5M+ data points', '99.9% uptime', 'Real-time sync']
            },
            {
              title: 'Model Training',
              icon: Brain,
              color: 'green',
              metrics: ['Daily retraining', 'Auto-optimization', 'Cross-validation']
            },
            {
              title: 'Inference Engine',
              icon: GitBranch,
              color: 'purple',
              metrics: ['47ms response', '99.8% accuracy', 'Load balanced']
            },
            {
              title: 'Continuous Learning',
              icon: RefreshCcw,
              color: 'indigo',
              metrics: ['Auto-adjustment', 'Performance tracking', 'Anomaly detection']
            }
          ].map((section, index) => (
            <div key={index} className="bg-gray-50 rounded-lg p-4">
              <h4 className="flex items-center text-gray-900 font-medium mb-3">
                <section.icon className="h-5 w-5 mr-2 text-blue-600" />
                {section.title}
              </h4>
              <ul className="space-y-2 text-gray-800 text-sm">
                {section.metrics.map((metric, idx) => (
                  <li key={idx}>{metric}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
      {/* Model Accuracy Metrics */}
      <div className="bg-white rounded-lg shadow-sm p-6">
        <h3 className="text-xl font-semibold text-gray-900 mb-6">Model Accuracy Metrics</h3>
        <Line data={modelAccuracyData} />
      </div>
    </div>
  );
};

export default MLPipelineView; 