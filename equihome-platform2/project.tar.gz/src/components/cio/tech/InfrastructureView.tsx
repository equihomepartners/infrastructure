import React from 'react';
import { Server, Cloud, Shield, Database, Network, Globe } from 'lucide-react';
import { Bar } from 'react-chartjs-2';

const InfrastructureView: React.FC = () => {
  // System performance metrics
  const performanceData = {
    labels: ['API Gateway', 'ML Pipeline', 'Data Processing', 'Auth Service', 'Storage'],
    datasets: [{
      label: 'Response Time (ms)',
      data: [42, 156, 89, 35, 28],
      backgroundColor: ['#3b82f6', '#10b981', '#6366f1', '#f59e0b', '#ef4444'],
      borderRadius: 8
    }]
  };

  return (
    <div className="space-y-8">
      {/* Infrastructure Overview */}
      <div className="bg-white rounded-lg shadow-sm p-6">
        <h3 className="text-xl font-semibold text-gray-900 mb-6">System Architecture</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-blue-50 rounded-lg p-4">
            <h4 className="flex items-center text-blue-900 font-medium mb-3">
              <Cloud className="h-5 w-5 mr-2" />
              Cloud Infrastructure
            </h4>
            <ul className="space-y-2 text-blue-800 text-sm">
              <li>• AWS Production Environment</li>
              <li>• Multi-AZ Deployment</li>
              <li>• Auto-scaling enabled</li>
              <li>• 99.99% SLA</li>
            </ul>
          </div>

          <div className="bg-green-50 rounded-lg p-4">
            <h4 className="flex items-center text-green-900 font-medium mb-3">
              <Database className="h-5 w-5 mr-2" />
              Data Storage
            </h4>
            <ul className="space-y-2 text-green-800 text-sm">
              <li>• Distributed Database</li>
              <li>• Real-time Replication</li>
              <li>• Automated Backups</li>
              <li>• Data Encryption</li>
            </ul>
          </div>

          <div className="bg-purple-50 rounded-lg p-4">
            <h4 className="flex items-center text-purple-900 font-medium mb-3">
              <Network className="h-5 w-5 mr-2" />
              Network Architecture
            </h4>
            <ul className="space-y-2 text-purple-800 text-sm">
              <li>• High-speed network</li>
              <li>• Load balancing</li>
              <li>• Secure VPN</li>
              <li>• Traffic monitoring</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Performance Metrics */}
      <div className="bg-white rounded-lg shadow-sm p-6">
        <h3 className="text-xl font-semibold text-gray-900 mb-6">System Performance</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-yellow-50 rounded-lg p-4">
            <h4 className="flex items-center text-yellow-900 font-medium mb-3">
              <Globe className="h-5 w-5 mr-2" />
              Global Reach
            </h4>
            <ul className="space-y-2 text-yellow-800 text-sm">
              <li>• 100+ data centers</li>
              <li>• 99.9% uptime</li>
              <li>• 100 Gbps network</li>
              <li>• 100% uptime SLA</li>
            </ul>
          </div>

          <div className="bg-red-50 rounded-lg p-4">
            <h4 className="flex items-center text-red-900 font-medium mb-3">
              <Shield className="h-5 w-5 mr-2" />
              Security
            </h4>
            <ul className="space-y-2 text-red-800 text-sm">
              <li>• 24/7 security monitoring</li>
              <li>• DDoS protection</li>
              <li>• SSL/TLS encryption</li>
              <li>• IAM access control</li>
            </ul>
          </div>

          <div className="bg-pink-50 rounded-lg p-4">
            <h4 className="flex items-center text-pink-900 font-medium mb-3">
              <Server className="h-5 w-5 mr-2" />
              Server Performance
            </h4>
            <ul className="space-y-2 text-pink-800 text-sm">
              <li>• 100% CPU utilization</li>
              <li>• 99.9% memory utilization</li>
              <li>• 99.9% disk utilization</li>
              <li>• 99.9% network utilization</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InfrastructureView; 