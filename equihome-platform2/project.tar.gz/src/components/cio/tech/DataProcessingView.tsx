import React from 'react';
import { Database, ArrowRight, RefreshCcw, Zap, Server, Shield } from 'lucide-react';
import { Bar, Line } from 'react-chartjs-2';

const DataProcessingView: React.FC = () => {
  // Sample metrics for visualization
  const processingMetrics = {
    averageResponseTime: '47ms',
    dataAccuracy: '99.8%',
    dailyTransactions: '2,450',
    dataPoints: '1.2M',
    uptime: '99.99%'
  };

  // Sample chart data for API performance
  const apiPerformanceData = {
    labels: ['PropTrack', 'CoreLogic', 'Domain', 'Government', 'Banking'],
    datasets: [{
      label: 'Response Time (ms)',
      data: [45, 52, 38, 62, 41],
      backgroundColor: ['#3b82f6', '#10b981', '#6366f1', '#f59e0b', '#ef4444'],
      borderRadius: 8
    }]
  };

  return (
    <div className="space-y-8">
      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
        {[
          { label: 'Avg Response Time', value: processingMetrics.averageResponseTime, icon: Zap },
          { label: 'Data Accuracy', value: processingMetrics.dataAccuracy, icon: RefreshCcw },
          { label: 'Daily Transactions', value: processingMetrics.dailyTransactions, icon: ArrowRight },
          { label: 'Total Data Points', value: processingMetrics.dataPoints, icon: Database },
          { label: 'System Uptime', value: processingMetrics.uptime, icon: Server }
        ].map((metric, index) => (
          <div key={index} className="bg-white rounded-lg shadow-sm p-4">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center">
                <metric.icon className="w-6 h-6 text-gray-500 mr-2" />
                <span className="text-sm font-medium text-gray-700">{metric.label}</span>
              </div>
              <div className="text-lg font-semibold text-gray-900">{metric.value}</div>
            </div>
          </div>
        ))}
      </div>

      {/* API Performance */}
      <div className="bg-white rounded-lg shadow-sm p-4">
        <h2 className="text-lg font-semibold mb-4">API Performance</h2>
        <Line data={apiPerformanceData} />
      </div>
    </div>
  );
};

export default DataProcessingView; 