export interface ZoneData {
  green: string[];
  orange: string[];
  red: string[];
}

export const trafficLightZones: ZoneData = {
  green: [
    'Mosman',
    'Double Bay',
    'Neutral Bay',
    'Cremorne',
    'Bronte',
    'Bellevue Hill',
    'Rose Bay',
    'Vaucluse',
    'Woollahra',
    'Paddington',
    'North Sydney',
    'Kirribilli',
    'Balmoral',
    'Manly',
    'Freshwater',
    'Curl Curl',
    'Dee Why',
    'Pymble',
    'Gordon',
    'Killara'
  ],
  orange: [
    'Marrickville',
    'Ashfield',
    'Burwood',
    'Strathfield',
    'Chatswood',
    'Lane Cove',
    'St Leonards',
    'Artarmon',
    'Willoughby',
    'Northbridge',
    'Crows Nest',
    'Randwick',
    'Coogee',
    'Maroubra',
    'Bondi Junction',
    'Bondi Beach',
    'Leichhardt',
    'Balmain',
    'Rozelle',
    'Drummoyne'
  ],
  red: [
    'Blacktown',
    'Mount Druitt',
    'Penrith',
    'St Marys',
    'Liverpool',
    'Campbelltown',
    'Bankstown',
    'Auburn',
    'Granville',
    'Merrylands',
    'Guildford',
    'Fairfield',
    'Cabramatta',
    'Canterbury',
    'Lakemba',
    'Punchbowl',
    'Yagoona',
    'Bass Hill',
    'Chester Hill',
    'Sefton'
  ]
};